print('version 0.9.2  (c) 2022 Isabel Sandstrom Hermit AS\n\n\
    Python command line program for converting different files to pdf.\
     You can convert word documents, excel documents and images with the three different commands convertword, convertexcel and convertimage.')